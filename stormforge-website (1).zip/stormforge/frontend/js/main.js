// ============================================
// StormForge - Shared Components & Utilities
// ============================================

const API = '';

// ---- TOAST ----
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.textContent = (icons[type] || '') + ' ' + message;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(40px)'; toast.style.transition = 'all 0.3s'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// ---- API HELPER ----
async function apiFetch(url, options = {}) {
  const token = localStorage.getItem('sf_token');
  const headers = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) };
  const res = await fetch(API + url, { ...options, headers, credentials: 'include' });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---- AUTH CHECK ----
function getUser() {
  const u = localStorage.getItem('sf_user');
  return u ? JSON.parse(u) : null;
}

function isLoggedIn() { return !!localStorage.getItem('sf_token'); }

async function logout() {
  await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  localStorage.removeItem('sf_token');
  localStorage.removeItem('sf_user');
  window.location.href = '/login';
}

// ---- NAVBAR ----
function renderNavbar() {
  const currentPath = window.location.pathname;
  const nav = document.getElementById('main-navbar');
  if (!nav) return;
  nav.innerHTML = `
    <a href="/" class="nav-logo">
      <div style="width:40px;height:40px;border-radius:8px;background:linear-gradient(135deg,#00c8ff,#00f0c8);display:flex;align-items:center;justify-content:center;font-size:20px;">⚡</div>
      <span class="nav-logo-text">STORMFORGE</span>
    </a>
    <ul class="nav-links">
      <li><a href="/" class="${currentPath==='/'?'active':''}">Home</a></li>
      <li><a href="/category/discord-nitro" class="">Shop</a></li>
      <li><a href="/offers" class="${currentPath==='/offers'?'active':''}">Offers</a></li>
      <li><a href="/reviews" class="${currentPath==='/reviews'?'active':''}">Reviews</a></li>
      <li><a href="/about" class="${currentPath==='/about'?'active':''}">About</a></li>
      <li><a href="/rules" class="${currentPath==='/rules'?'active':''}">Rules</a></li>
      <li><a href="/support" class="${currentPath==='/support'?'active':''}">Support</a></li>
      <li><a href="/social" class="${currentPath==='/social'?'active':''}">Social</a></li>
      <li><a href="/contact" class="${currentPath==='/contact'?'active':''}">Contact</a></li>
    </ul>
    <a href="#" id="discord-join-btn" class="nav-discord-btn">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.08.114 18.1.132 18.11a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/></svg>
      Join Discord
    </a>
    <button class="hamburger" id="hamburger-btn" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  `;

  // Mobile nav
  let mobileNav = document.getElementById('mobile-nav');
  if (!mobileNav) {
    mobileNav = document.createElement('div');
    mobileNav.className = 'mobile-nav';
    mobileNav.id = 'mobile-nav';
    mobileNav.innerHTML = `
      <button class="mobile-nav-close" id="mobile-close">✕</button>
      <a href="/">Home</a>
      <a href="/offers">Offers</a>
      <a href="/reviews">Reviews</a>
      <a href="/about">About</a>
      <a href="/rules">Rules</a>
      <a href="/support">Support</a>
      <a href="/social">Social</a>
      <a href="/contact">Contact</a>
    `;
    document.body.appendChild(mobileNav);
  }

  document.getElementById('hamburger-btn')?.addEventListener('click', () => mobileNav.classList.add('open'));
  document.getElementById('mobile-close')?.addEventListener('click', () => mobileNav.classList.remove('open'));

  // Load discord link
  fetch('/api/settings').then(r => r.json()).then(s => {
    document.getElementById('discord-join-btn').href = s.discord_invite || '#';
  }).catch(() => {});

  // Scroll effect
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 50);
  });
}

// ---- FOOTER ----
async function renderFooter() {
  const footer = document.getElementById('main-footer');
  if (!footer) return;
  let links = [];
  try { links = await apiFetch('/api/settings/social'); } catch {}

  const socialIcons = { discord: '🎮', youtube: '▶️', tiktok: '🎵', instagram: '📸', facebook: '📘', twitter: '🐦', x: '✖️' };

  footer.innerHTML = `
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="nav-logo-text">⚡ STORMFORGE</div>
          <p class="footer-desc">Pakistan's most trusted Discord shop. Premium digital products at the best prices. Fast delivery, 100% verified.</p>
          <div class="footer-social">
            ${links.map(l => `<a href="${l.url}" target="_blank" class="social-icon" title="${l.platform}">${socialIcons[l.icon] || '🔗'}</a>`).join('')}
          </div>
        </div>
        <div>
          <div class="footer-title">Shop</div>
          <ul class="footer-links">
            <li><a href="/category/discord-nitro">Discord Nitro</a></li>
            <li><a href="/category/discord-boost">Server Boost</a></li>
            <li><a href="/category/minecraft-premium">Minecraft</a></li>
            <li><a href="/category/netflix">Netflix</a></li>
            <li><a href="/category/roblox">Roblox</a></li>
            <li><a href="/offers">Special Offers</a></li>
          </ul>
        </div>
        <div>
          <div class="footer-title">Info</div>
          <ul class="footer-links">
            <li><a href="/about">About Us</a></li>
            <li><a href="/rules">Rules</a></li>
            <li><a href="/reviews">Reviews</a></li>
            <li><a href="/contact">Contact</a></li>
            <li><a href="/social">Social Media</a></li>
          </ul>
        </div>
        <div>
          <div class="footer-title">Support</div>
          <ul class="footer-links">
            <li><a href="/support">Live Chat</a></li>
            <li><a href="/contact">Email Us</a></li>
            <li><a href="#discord-join-btn">Discord Server</a></li>
          </ul>
          <div style="margin-top:20px;padding:16px;background:rgba(0,200,255,0.05);border:1px solid rgba(0,200,255,0.15);border-radius:12px;">
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">SUPPORT HOURS</div>
            <div style="font-size:14px;color:var(--text-primary);">24/7 via Discord</div>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2024 StormForge. Founded by Shayan & Atif. All rights reserved.</p>
        <p>Payments in PKR & INR · Instant Delivery</p>
      </div>
    </div>
  `;
}

// ---- SCROLL ANIMATIONS ----
function initScrollAnimations() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
  }, { threshold: 0.1 });
  document.querySelectorAll('.animate-up').forEach(el => observer.observe(el));
}

// ---- SUPPORT WIDGET ----
function renderSupportWidget() {
  const w = document.getElementById('support-widget');
  if (!w) return;
  w.innerHTML = `
    <button class="support-btn" onclick="window.location.href='/support'" title="Live Support">
      💬
      <span class="notif-dot"></span>
    </button>
  `;
}

// ---- STARS RENDER ----
function renderStars(rating, max = 5) {
  return Array.from({ length: max }, (_, i) =>
    `<span class="star ${i < rating ? 'filled' : ''}">★</span>`
  ).join('');
}

// ---- FORMAT DATE ----
function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-PK', { year: 'numeric', month: 'short', day: 'numeric' });
}

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  renderNavbar();
  renderFooter();
  renderSupportWidget();
  initScrollAnimations();
});
