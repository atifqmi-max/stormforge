// ============================================
// StormForge - Admin Panel JS
// ============================================

// Auth check
if (!isLoggedIn()) window.location.href = '/login';

const user = getUser();
if (user) {
  document.getElementById('sb-name').textContent = user.name;
  document.getElementById('sb-role').textContent = user.role === 'admin' ? 'Administrator' : 'Staff';
  document.getElementById('sb-avatar').textContent = user.name.charAt(0).toUpperCase();
}

// Mobile menu
if (window.innerWidth < 900) {
  document.getElementById('menu-btn').style.display = 'block';
}

// ---- PAGE NAVIGATION ----
function showPage(name) {
  document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  document.querySelectorAll('.sidebar-link').forEach(l => {
    if (l.getAttribute('onclick') === `showPage('${name}')`) l.classList.add('active');
  });
  document.getElementById('page-title').textContent = {
    dashboard: 'Dashboard', products: 'Products', categories: 'Categories',
    offers: 'Special Offers', reviews: 'Reviews', chats: 'Live Chats',
    staff: 'Staff & Roles', social: 'Social Links', settings: 'Settings'
  }[name] || name;

  // Lazy load
  if (name === 'dashboard') loadDashboard();
  if (name === 'products') loadProducts();
  if (name === 'categories') loadCategories();
  if (name === 'offers') loadOffers();
  if (name === 'reviews') loadReviews();
  if (name === 'chats') loadChats();
  if (name === 'staff') loadStaff();
  if (name === 'social') loadSocialLinks();
  if (name === 'settings') loadSettings();
}

function doLogout() { logout(); }

// ---- DASHBOARD ----
async function loadDashboard() {
  try {
    const [products, cats, reviews, offers, chats] = await Promise.all([
      apiFetch('/api/products'), apiFetch('/api/categories'),
      apiFetch('/api/reviews/admin/all'), apiFetch('/api/offers/admin/all'),
      apiFetch('/api/chats')
    ]);
    const pending = reviews.filter(r => !r.approved).length;
    const openChats = chats.filter(c => c.status === 'open').length;

    // Update badges
    if (pending > 0) { document.getElementById('pending-badge').textContent = pending; document.getElementById('pending-badge').style.display = ''; }
    if (openChats > 0) { document.getElementById('chat-badge').textContent = openChats; document.getElementById('chat-badge').style.display = ''; }

    document.getElementById('stats-grid').innerHTML = `
      <div class="stat-card blue"><div class="stat-card-icon">📦</div><div class="stat-card-value">${products.length}</div><div class="stat-card-label">Total Products</div></div>
      <div class="stat-card gold"><div class="stat-card-icon">🏷️</div><div class="stat-card-value">${cats.length}</div><div class="stat-card-label">Categories</div></div>
      <div class="stat-card purple"><div class="stat-card-icon">⭐</div><div class="stat-card-value">${reviews.length}</div><div class="stat-card-label">Total Reviews</div></div>
      <div class="stat-card red"><div class="stat-card-icon">⏳</div><div class="stat-card-value">${pending}</div><div class="stat-card-label">Pending Reviews</div></div>
      <div class="stat-card blue"><div class="stat-card-icon">🔥</div><div class="stat-card-value">${offers.length}</div><div class="stat-card-label">Active Offers</div></div>
      <div class="stat-card gold"><div class="stat-card-icon">💬</div><div class="stat-card-value">${openChats}</div><div class="stat-card-label">Open Chats</div></div>
    `;

    // Latest products
    const latest = [...products].sort((a,b) => new Date(b.created_at)-new Date(a.created_at)).slice(0,5);
    document.getElementById('dash-latest-products').innerHTML = latest.length
      ? latest.map(p => `<div style="padding:10px 16px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
          <div><div style="font-weight:600;font-size:14px;">${p.title}</div><div style="font-size:12px;color:var(--text-muted);">${formatDate(p.created_at)}</div></div>
          <div style="font-weight:600;color:var(--accent-blue);">Rs. ${p.price_pkr.toLocaleString()}</div>
        </div>`).join('')
      : '<div style="padding:16px;color:var(--text-muted);">No products yet.</div>';

    // Pending reviews
    const pendingRevs = reviews.filter(r => !r.approved).slice(0,5);
    document.getElementById('dash-pending-reviews').innerHTML = pendingRevs.length
      ? pendingRevs.map(r => `<div style="padding:10px 16px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;gap:12px;">
          <div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:14px;">${r.discord_username}</div><div style="font-size:12px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${r.content}</div></div>
          <button class="btn btn-success btn-sm" onclick="approveReview('${r.id}')">Approve</button>
        </div>`).join('')
      : '<div style="padding:16px;color:var(--text-muted);">No pending reviews.</div>';
  } catch(e) { showToast('Dashboard load failed', 'error'); }
}

// ---- PRODUCTS ----
let allProducts = [], allCategories = [];

async function loadProducts() {
  try {
    [allProducts, allCategories] = await Promise.all([apiFetch('/api/products'), apiFetch('/api/categories')]);
    const sel = document.getElementById('product-cat-filter');
    sel.innerHTML = '<option value="">All Categories</option>' + allCategories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    renderProductsTable(allProducts);
  } catch(e) { showToast('Failed to load products', 'error'); }
}

function filterProducts() {
  const q = document.getElementById('product-search').value.toLowerCase();
  const cat = document.getElementById('product-cat-filter').value;
  let filtered = allProducts;
  if (q) filtered = filtered.filter(p => p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
  if (cat) filtered = filtered.filter(p => p.category_id === cat);
  renderProductsTable(filtered);
}

function renderProductsTable(products) {
  const tbody = document.getElementById('products-table-body');
  if (!products.length) { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted);">No products found.</td></tr>'; return; }
  tbody.innerHTML = products.map(p => {
    const cat = allCategories.find(c => c.id === p.category_id);
    return `<tr>
      <td><div style="font-weight:600;">${p.title}</div><div style="font-size:12px;color:var(--text-muted);">${p.description.substring(0,40)}...</div></td>
      <td>${cat ? `<span style="background:${cat.color}22;color:${cat.color};padding:3px 10px;border-radius:6px;font-size:12px;font-weight:600;">${cat.icon} ${cat.name}</span>` : '-'}</td>
      <td style="color:var(--accent-blue);font-weight:600;">Rs. ${p.price_pkr.toLocaleString()}</td>
      <td style="color:var(--text-muted);">₹${p.price_inr.toLocaleString()}</td>
      <td><span class="stock-badge ${p.stock==='in_stock'?'stock-in':'stock-out'}" style="font-size:11px;">${p.stock==='in_stock'?'In Stock':'Out of Stock'}</span></td>
      <td>${p.featured ? '<span style="color:var(--accent-gold);">⭐ Yes</span>' : '<span style="color:var(--text-muted);">No</span>'}</td>
      <td class="td-actions">
        <button class="btn btn-outline btn-sm" onclick="openProductModal('${p.id}')">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteProduct('${p.id}')">🗑️</button>
      </td>
    </tr>`;
  }).join('');
}

function openProductModal(id = null) {
  const p = id ? allProducts.find(x => x.id === id) : null;
  showModal(`${p ? 'Edit' : 'Add'} Product`, `
    <div id="product-alert"></div>
    <div class="form-group"><label class="form-label">Title *</label><input type="text" class="form-control" id="pm-title" value="${p?.title||''}"></div>
    <div class="form-group"><label class="form-label">Category *</label>
      <select class="form-control" id="pm-cat">
        ${allCategories.map(c => `<option value="${c.id}" ${p?.category_id===c.id?'selected':''}>${c.icon} ${c.name}</option>`).join('')}
      </select>
    </div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-control" id="pm-desc">${p?.description||''}</textarea></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
      <div class="form-group"><label class="form-label">Price (PKR) *</label><input type="number" class="form-control" id="pm-pkr" value="${p?.price_pkr||''}"></div>
      <div class="form-group"><label class="form-label">Price (INR) *</label><input type="number" class="form-control" id="pm-inr" value="${p?.price_inr||''}"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
      <div class="form-group"><label class="form-label">Stock Status</label>
        <select class="form-control" id="pm-stock">
          <option value="in_stock" ${p?.stock==='in_stock'?'selected':''}>In Stock</option>
          <option value="out_of_stock" ${p?.stock==='out_of_stock'?'selected':''}>Out of Stock</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Featured?</label>
        <select class="form-control" id="pm-featured">
          <option value="false" ${!p?.featured?'selected':''}>No</option>
          <option value="true" ${p?.featured?'selected':''}>Yes ⭐</option>
        </select>
      </div>
    </div>
    <div class="form-group"><label class="form-label">Product Image</label><input type="file" class="form-control" id="pm-image" accept="image/*"></div>
    <button class="btn btn-primary" style="width:100%;justify-content:center;" onclick="saveProduct('${id||''}')">
      ${p ? '💾 Update Product' : '➕ Add Product'}
    </button>
  `);
}

async function saveProduct(id) {
  const fd = new FormData();
  fd.append('title', document.getElementById('pm-title').value.trim());
  fd.append('category_id', document.getElementById('pm-cat').value);
  fd.append('description', document.getElementById('pm-desc').value.trim());
  fd.append('price_pkr', document.getElementById('pm-pkr').value);
  fd.append('price_inr', document.getElementById('pm-inr').value);
  fd.append('stock', document.getElementById('pm-stock').value);
  fd.append('featured', document.getElementById('pm-featured').value);
  const img = document.getElementById('pm-image').files[0];
  if (img) fd.append('image', img);

  const alert = document.getElementById('product-alert');
  if (!fd.get('title') || !fd.get('price_pkr')) { alert.innerHTML = '<div class="alert alert-error">Title and price are required.</div>'; return; }

  try {
    const token = localStorage.getItem('sf_token');
    const url = id ? `/api/products/${id}` : '/api/products';
    const res = await fetch(url, { method: id ? 'PUT' : 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd, credentials: 'include' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    closeModal();
    showToast(id ? 'Product updated!' : 'Product added!', 'success');
    loadProducts();
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

async function deleteProduct(id) {
  if (!confirm('Delete this product?')) return;
  try {
    await apiFetch(`/api/products/${id}`, { method: 'DELETE' });
    showToast('Product deleted', 'success');
    loadProducts();
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- CATEGORIES ----
async function loadCategories() {
  try {
    const cats = await apiFetch('/api/categories');
    allCategories = cats;
    const tbody = document.getElementById('cats-table-body');
    if (!cats.length) { tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-muted);">No categories yet.</td></tr>'; return; }
    tbody.innerHTML = cats.map(c => `<tr>
      <td style="font-size:28px;">${c.icon}</td>
      <td><span style="background:${c.color}22;color:${c.color};padding:4px 12px;border-radius:6px;font-weight:600;">${c.name}</span></td>
      <td style="color:var(--text-muted);font-size:13px;">${c.slug}</td>
      <td style="color:var(--accent-blue);font-weight:600;">${c.product_count}</td>
      <td class="td-actions">
        <button class="btn btn-outline btn-sm" onclick="openCatModal('${c.id}')">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteCat('${c.id}')">🗑️</button>
      </td>
    </tr>`).join('');
  } catch(e) { showToast('Failed to load categories', 'error'); }
}

function openCatModal(id = null) {
  const cat = id ? allCategories.find(c => c.id === id) : null;
  showModal(`${cat ? 'Edit' : 'Add'} Category`, `
    <div id="cat-alert"></div>
    <div class="form-group"><label class="form-label">Name *</label><input type="text" class="form-control" id="cm-name" value="${cat?.name||''}"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
      <div class="form-group"><label class="form-label">Icon (emoji)</label><input type="text" class="form-control" id="cm-icon" value="${cat?.icon||'📦'}" placeholder="📦"></div>
      <div class="form-group"><label class="form-label">Color</label><input type="color" class="form-control" id="cm-color" value="${cat?.color||'#00c8ff'}" style="height:48px;padding:4px;cursor:pointer;"></div>
    </div>
    <button class="btn btn-primary" style="width:100%;justify-content:center;" onclick="saveCat('${id||''}')">
      ${cat ? '💾 Update' : '➕ Add Category'}
    </button>
  `);
}

async function saveCat(id) {
  const name = document.getElementById('cm-name').value.trim();
  const icon = document.getElementById('cm-icon').value.trim();
  const color = document.getElementById('cm-color').value;
  const alert = document.getElementById('cat-alert');
  if (!name) { alert.innerHTML = '<div class="alert alert-error">Name is required.</div>'; return; }
  try {
    const url = id ? `/api/categories/${id}` : '/api/categories';
    await apiFetch(url, { method: id ? 'PUT' : 'POST', body: JSON.stringify({ name, icon, color }) });
    closeModal();
    showToast(id ? 'Category updated!' : 'Category added!', 'success');
    loadCategories();
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

async function deleteCat(id) {
  if (!confirm('Delete this category and all its products?')) return;
  try {
    await apiFetch(`/api/categories/${id}`, { method: 'DELETE' });
    showToast('Category deleted', 'success');
    loadCategories();
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- OFFERS ----
let allOffers = [];
async function loadOffers() {
  try {
    allOffers = await apiFetch('/api/offers/admin/all');
    const tbody = document.getElementById('offers-table-body');
    if (!allOffers.length) { tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-muted);">No offers yet.</td></tr>'; return; }
    tbody.innerHTML = allOffers.map(o => `<tr>
      <td><div style="font-weight:600;">${o.title}</div><div style="font-size:12px;color:var(--text-muted);">${o.description.substring(0,50)}...</div></td>
      <td style="color:var(--accent-blue);font-weight:600;">Rs. ${o.price_pkr.toLocaleString()}</td>
      <td style="color:var(--text-muted);">₹${o.price_inr.toLocaleString()}</td>
      <td style="color:${o.expiry_date ? 'var(--accent-gold)' : 'var(--text-muted)'};">${o.expiry_date ? formatDate(o.expiry_date) : 'No expiry'}</td>
      <td class="td-actions">
        <button class="btn btn-outline btn-sm" onclick="openOfferModal('${o.id}')">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteOffer('${o.id}')">🗑️</button>
      </td>
    </tr>`).join('');
  } catch(e) { showToast('Failed to load offers', 'error'); }
}

function openOfferModal(id = null) {
  const o = id ? allOffers.find(x => x.id === id) : null;
  showModal(`${o ? 'Edit' : 'Add'} Special Offer`, `
    <div id="offer-alert"></div>
    <div class="form-group"><label class="form-label">Title *</label><input type="text" class="form-control" id="om-title" value="${o?.title||''}"></div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-control" id="om-desc">${o?.description||''}</textarea></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
      <div class="form-group"><label class="form-label">Price (PKR)</label><input type="number" class="form-control" id="om-pkr" value="${o?.price_pkr||''}"></div>
      <div class="form-group"><label class="form-label">Price (INR)</label><input type="number" class="form-control" id="om-inr" value="${o?.price_inr||''}"></div>
    </div>
    <div class="form-group"><label class="form-label">Expiry Date (optional)</label><input type="date" class="form-control" id="om-expiry" value="${o?.expiry_date||''}"></div>
    <div class="form-group"><label class="form-label">Image (optional)</label><input type="file" class="form-control" id="om-image" accept="image/*"></div>
    <button class="btn btn-gold" style="width:100%;justify-content:center;" onclick="saveOffer('${id||''}')">
      ${o ? '💾 Update Offer' : '🔥 Add Offer'}
    </button>
  `);
}

async function saveOffer(id) {
  const fd = new FormData();
  fd.append('title', document.getElementById('om-title').value.trim());
  fd.append('description', document.getElementById('om-desc').value.trim());
  fd.append('price_pkr', document.getElementById('om-pkr').value);
  fd.append('price_inr', document.getElementById('om-inr').value);
  fd.append('expiry_date', document.getElementById('om-expiry').value);
  const img = document.getElementById('om-image').files[0];
  if (img) fd.append('image', img);
  const alert = document.getElementById('offer-alert');
  if (!fd.get('title')) { alert.innerHTML = '<div class="alert alert-error">Title is required.</div>'; return; }
  try {
    const token = localStorage.getItem('sf_token');
    const url = id ? `/api/offers/${id}` : '/api/offers';
    const res = await fetch(url, { method: id ? 'PUT' : 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd, credentials: 'include' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    closeModal();
    showToast(id ? 'Offer updated!' : 'Offer added!', 'success');
    loadOffers();
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

async function deleteOffer(id) {
  if (!confirm('Delete this offer?')) return;
  try {
    await apiFetch(`/api/offers/${id}`, { method: 'DELETE' });
    showToast('Offer deleted', 'success');
    loadOffers();
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- REVIEWS ----
let allReviews = [], reviewFilter = 'all';

async function loadReviews() {
  try {
    allReviews = await apiFetch('/api/reviews/admin/all');
    renderReviewsTable();
  } catch(e) { showToast('Failed to load reviews', 'error'); }
}

function filterReviews(filter, btn) {
  reviewFilter = filter;
  document.querySelectorAll('#page-reviews .admin-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  renderReviewsTable();
}

function renderReviewsTable() {
  const filtered = reviewFilter === 'all' ? allReviews : reviewFilter === 'pending' ? allReviews.filter(r => !r.approved) : allReviews.filter(r => r.approved);
  const tbody = document.getElementById('reviews-table-body');
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-muted);">No reviews found.</td></tr>'; return; }
  tbody.innerHTML = filtered.map(r => `<tr>
    <td><div style="font-weight:600;">${r.discord_username}</div><div style="font-size:12px;color:var(--text-muted);">ID: ${r.discord_id||'N/A'}</div></td>
    <td>${renderStars(r.rating)}</td>
    <td style="max-width:250px;"><div style="font-size:13px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">"${r.content}"</div></td>
    <td style="font-size:12px;color:var(--text-muted);">${formatDate(r.created_at)}</td>
    <td>${r.approved ? '<span class="stock-badge stock-in" style="font-size:11px;">Approved</span>' : '<span class="stock-badge stock-out" style="font-size:11px;">Pending</span>'}</td>
    <td class="td-actions">
      ${!r.approved ? `<button class="btn btn-success btn-sm" onclick="approveReview('${r.id}')">✅ Approve</button>` : ''}
      <button class="btn btn-danger btn-sm" onclick="deleteReview('${r.id}')">🗑️</button>
    </td>
  </tr>`).join('');
}

async function approveReview(id) {
  try {
    await apiFetch(`/api/reviews/${id}/approve`, { method: 'PUT' });
    showToast('Review approved!', 'success');
    loadReviews(); loadDashboard();
  } catch(e) { showToast(e.message, 'error'); }
}

async function deleteReview(id) {
  if (!confirm('Delete this review?')) return;
  try {
    await apiFetch(`/api/reviews/${id}`, { method: 'DELETE' });
    showToast('Review deleted', 'success');
    loadReviews();
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- CHATS ----
let allChats = [], selectedChatId = null, adminSocket = null;

async function loadChats() {
  try {
    allChats = await apiFetch('/api/chats');
    renderChatList();
    if (!adminSocket) {
      adminSocket = io();
      adminSocket.emit('join_admin');
      adminSocket.on('chat_updated', (chat) => {
        const idx = allChats.findIndex(c => c.id === chat.id);
        if (idx !== -1) allChats[idx] = chat;
        else allChats.unshift(chat);
        renderChatList();
        if (selectedChatId === chat.id) renderChatMessages(chat);
      });
    }
  } catch(e) { showToast('Failed to load chats', 'error'); }
}

function renderChatList() {
  const list = document.getElementById('admin-chat-list');
  if (!allChats.length) { list.innerHTML = '<div style="padding:20px;color:var(--text-muted);font-size:14px;">No chats yet.</div>'; return; }
  list.innerHTML = allChats.map(c => `
    <div class="chat-list-item ${c.id === selectedChatId ? 'selected' : ''}" onclick="selectChat('${c.id}')">
      <div style="flex:1;min-width:0;">
        <div style="font-weight:600;font-size:14px;margin-bottom:2px;">${c.name}</div>
        <div style="font-size:12px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${c.email}</div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${c.messages.length} messages</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;">
        <div class="${c.status==='open'?'chat-open-dot':'chat-closed-dot'}"></div>
        <div style="font-size:10px;color:var(--text-muted);">${c.status}</div>
      </div>
    </div>`).join('');
}

function selectChat(id) {
  selectedChatId = id;
  const chat = allChats.find(c => c.id === id);
  if (!chat) return;
  renderChatList();
  renderChatMessages(chat);
  if (adminSocket) adminSocket.emit('join_chat', id);
}

function renderChatMessages(chat) {
  const main = document.getElementById('admin-chat-main');
  main.innerHTML = `
    <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
      <div>
        <div style="font-weight:600;">${chat.name}</div>
        <div style="font-size:12px;color:var(--text-muted);">${chat.email} · ${chat.status}</div>
      </div>
      <div style="display:flex;gap:8px;">
        ${chat.status === 'open' ? `<button class="btn btn-danger btn-sm" onclick="closeChat('${chat.id}')">Close Chat</button>` : ''}
        <button class="btn btn-danger btn-sm" onclick="deleteChat('${chat.id}')">Delete</button>
      </div>
    </div>
    <div class="chat-msg-area" id="admin-msgs-${chat.id}">
      ${chat.messages.map(m => `
        <div class="msg ${m.from==='system'?'msg-system':m.from==='admin'?'msg-admin':'msg-user'}">
          ${m.from==='admin'?`<div class="msg-name">⚡ ${m.admin_name||'Support'}</div>`:''}
          ${m.text}
          <div class="msg-time">${new Date(m.time).toLocaleTimeString()}</div>
        </div>`).join('')}
    </div>
    ${chat.status === 'open' ? `
      <div class="chat-reply-bar">
        <input type="text" class="form-control" id="admin-reply-input" placeholder="Type your reply..." onkeydown="if(event.key==='Enter')sendAdminReply('${chat.id}')">
        <button class="btn btn-primary" onclick="sendAdminReply('${chat.id}')">Reply</button>
      </div>` : '<div style="padding:16px;text-align:center;color:var(--text-muted);font-size:13px;">This chat is closed.</div>'}
  `;
  const msgArea = document.getElementById(`admin-msgs-${chat.id}`);
  if (msgArea) msgArea.scrollTop = msgArea.scrollHeight;
}

async function sendAdminReply(chatId) {
  const input = document.getElementById('admin-reply-input');
  const message = input.value.trim();
  if (!message) return;
  input.value = '';
  try {
    if (adminSocket) {
      adminSocket.emit('admin_reply', { chatId, message, adminName: user?.name || 'Admin' });
    } else {
      const data = await apiFetch(`/api/chats/${chatId}/reply`, { method: 'POST', body: JSON.stringify({ message }) });
      const chat = allChats.find(c => c.id === chatId);
      if (chat) { chat.messages = data.chat.messages; renderChatMessages(chat); }
    }
  } catch(e) { showToast('Failed to send reply', 'error'); }
}

async function closeChat(id) {
  try {
    await apiFetch(`/api/chats/${id}/close`, { method: 'PUT' });
    showToast('Chat closed', 'success');
    loadChats();
  } catch(e) { showToast(e.message, 'error'); }
}

async function deleteChat(id) {
  if (!confirm('Delete this chat?')) return;
  try {
    await apiFetch(`/api/chats/${id}`, { method: 'DELETE' });
    selectedChatId = null;
    showToast('Chat deleted', 'success');
    loadChats();
    document.getElementById('admin-chat-main').innerHTML = '<div style="flex:1;display:flex;align-items:center;justify-content:center;color:var(--text-muted);"><div style="text-align:center;"><div style="font-size:48px;margin-bottom:12px;">💬</div><div>Select a chat</div></div></div>';
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- STAFF ----
async function loadStaff() {
  try {
    const staff = await apiFetch('/api/auth/staff');
    const tbody = document.getElementById('staff-table-body');
    if (!staff.length) { tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-muted);">No staff accounts yet.</td></tr>'; return; }
    tbody.innerHTML = staff.map(s => `<tr>
      <td style="font-weight:600;">${s.name}</td>
      <td style="color:var(--text-muted);">${s.email}</td>
      <td><span style="background:rgba(124,58,237,0.15);color:#a78bfa;padding:3px 10px;border-radius:6px;font-size:12px;">${s.role}</span></td>
      <td style="font-size:12px;color:var(--text-muted);">${(s.permissions||[]).join(', ')}</td>
      <td class="td-actions"><button class="btn btn-danger btn-sm" onclick="deleteStaff('${s.id}')">🗑️ Remove</button></td>
    </tr>`).join('');
  } catch(e) { showToast('Failed to load staff', 'error'); }
}

function openStaffModal() {
  showModal('Add Staff Account', `
    <div id="staff-alert"></div>
    <div class="form-group"><label class="form-label">Name *</label><input type="text" class="form-control" id="sm-name" placeholder="Staff name"></div>
    <div class="form-group"><label class="form-label">Email *</label><input type="email" class="form-control" id="sm-email" placeholder="staff@example.com"></div>
    <div class="form-group"><label class="form-label">Password *</label><input type="password" class="form-control" id="sm-pass" placeholder="Strong password"></div>
    <div class="form-group"><label class="form-label">Permissions</label>
      <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:8px;">
        ${['all','products','reviews','offers','chat'].map(p => `
          <label style="display:flex;align-items:center;gap:6px;font-size:14px;cursor:pointer;">
            <input type="checkbox" value="${p}" class="perm-check" ${p==='chat'?'checked':''}> ${p}
          </label>`).join('')}
      </div>
    </div>
    <button class="btn btn-primary" style="width:100%;justify-content:center;" onclick="saveStaff()">➕ Add Staff</button>
  `);
}

async function saveStaff() {
  const name = document.getElementById('sm-name').value.trim();
  const email = document.getElementById('sm-email').value.trim();
  const password = document.getElementById('sm-pass').value;
  const permissions = [...document.querySelectorAll('.perm-check:checked')].map(c => c.value);
  const alert = document.getElementById('staff-alert');
  if (!name || !email || !password) { alert.innerHTML = '<div class="alert alert-error">All fields are required.</div>'; return; }
  try {
    await apiFetch('/api/auth/staff', { method: 'POST', body: JSON.stringify({ name, email, password, permissions }) });
    closeModal();
    showToast('Staff account created!', 'success');
    loadStaff();
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

async function deleteStaff(id) {
  if (!confirm('Remove this staff account?')) return;
  try {
    await apiFetch(`/api/auth/staff/${id}`, { method: 'DELETE' });
    showToast('Staff removed', 'success');
    loadStaff();
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- SOCIAL LINKS ----
let allSocialLinks = [];
async function loadSocialLinks() {
  try {
    allSocialLinks = await apiFetch('/api/settings/social');
    const tbody = document.getElementById('social-table-body');
    if (!allSocialLinks.length) { tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:32px;color:var(--text-muted);">No social links yet.</td></tr>'; return; }
    tbody.innerHTML = allSocialLinks.map(l => `<tr>
      <td style="font-weight:600;">${l.platform}</td>
      <td><a href="${l.url}" target="_blank" style="color:var(--accent-blue);font-size:13px;">${l.url}</a></td>
      <td style="color:var(--text-muted);">${l.icon}</td>
      <td class="td-actions">
        <button class="btn btn-outline btn-sm" onclick="openSocialModal('${l.id}')">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteSocialLink('${l.id}')">🗑️</button>
      </td>
    </tr>`).join('');
  } catch(e) { showToast('Failed to load social links', 'error'); }
}

function openSocialModal(id = null) {
  const l = id ? allSocialLinks.find(x => x.id === id) : null;
  showModal(`${l ? 'Edit' : 'Add'} Social Link`, `
    <div id="social-alert"></div>
    <div class="form-group"><label class="form-label">Platform *</label><input type="text" class="form-control" id="slm-platform" value="${l?.platform||''}" placeholder="e.g. Discord"></div>
    <div class="form-group"><label class="form-label">URL *</label><input type="url" class="form-control" id="slm-url" value="${l?.url||''}" placeholder="https://..."></div>
    <div class="form-group"><label class="form-label">Icon Key</label>
      <select class="form-control" id="slm-icon">
        ${['discord','youtube','tiktok','instagram','facebook','twitter','x'].map(i => `<option value="${i}" ${l?.icon===i?'selected':''}>${i}</option>`).join('')}
      </select>
    </div>
    <button class="btn btn-primary" style="width:100%;justify-content:center;" onclick="saveSocialLink('${id||''}')">
      ${l ? '💾 Update' : '➕ Add Link'}
    </button>
  `);
}

async function saveSocialLink(id) {
  const platform = document.getElementById('slm-platform').value.trim();
  const url = document.getElementById('slm-url').value.trim();
  const icon = document.getElementById('slm-icon').value;
  const alert = document.getElementById('social-alert');
  if (!platform || !url) { alert.innerHTML = '<div class="alert alert-error">Platform and URL are required.</div>'; return; }
  try {
    const endpoint = id ? `/api/settings/social/${id}` : '/api/settings/social';
    await apiFetch(endpoint, { method: id ? 'PUT' : 'POST', body: JSON.stringify({ platform, url, icon }) });
    closeModal();
    showToast(id ? 'Link updated!' : 'Link added!', 'success');
    loadSocialLinks();
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

async function deleteSocialLink(id) {
  if (!confirm('Delete this link?')) return;
  try {
    await apiFetch(`/api/settings/social/${id}`, { method: 'DELETE' });
    showToast('Link deleted', 'success');
    loadSocialLinks();
  } catch(e) { showToast(e.message, 'error'); }
}

// ---- SETTINGS ----
async function loadSettings() {
  try {
    const s = await apiFetch('/api/settings');
    document.getElementById('s-name').value = s.shop_name || '';
    document.getElementById('s-tagline').value = s.shop_tagline || '';
    document.getElementById('s-discord').value = s.discord_invite || '';
    if (user) {
      document.getElementById('c-name').value = user.name || '';
      document.getElementById('c-email').value = user.email || '';
    }
  } catch(e) {}
}

async function saveSettings() {
  const alert = document.getElementById('settings-alert');
  try {
    await apiFetch('/api/settings', { method: 'PUT', body: JSON.stringify({
      shop_name: document.getElementById('s-name').value,
      shop_tagline: document.getElementById('s-tagline').value,
      discord_invite: document.getElementById('s-discord').value
    })});
    alert.innerHTML = '<div class="alert alert-success">✅ Settings saved!</div>';
    setTimeout(() => alert.innerHTML = '', 3000);
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

async function saveCredentials() {
  const alert = document.getElementById('creds-alert');
  const body = {};
  const email = document.getElementById('c-email').value.trim();
  const name = document.getElementById('c-name').value.trim();
  const pass = document.getElementById('c-pass').value;
  if (email) body.email = email;
  if (name) body.name = name;
  if (pass) body.password = pass;
  if (!Object.keys(body).length) { alert.innerHTML = '<div class="alert alert-info">Nothing to update.</div>'; return; }
  try {
    await apiFetch('/api/auth/update-credentials', { method: 'PUT', body: JSON.stringify(body) });
    alert.innerHTML = '<div class="alert alert-success">✅ Credentials updated! Please re-login.</div>';
    setTimeout(() => doLogout(), 2000);
  } catch(e) { alert.innerHTML = `<div class="alert alert-error">${e.message}</div>`; }
}

// ---- MODAL HELPER ----
function showModal(title, content) {
  document.getElementById('modal-container').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-header">
          <div class="modal-title">${title}</div>
          <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        ${content}
      </div>
    </div>`;
}

function closeModal() {
  document.getElementById('modal-container').innerHTML = '';
}

// ---- INIT ----
loadDashboard();
