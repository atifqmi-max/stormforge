const fs = require('fs');
const path = require('path');
const DATA_DIR = path.join(__dirname, '../data');

function initDB() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  const bcrypt = require('bcryptjs');

  const defaults = {
    'settings.json': {
      discord_invite: 'https://discord.gg/stormforge',
      shop_name: 'StormForge',
      shop_tagline: 'Premium Digital Products'
    },
    'users.json': [{
      id: '1', email: 'admin@stormforge.fun',
      password: bcrypt.hashSync('stormforge-admin-381', 10),
      name: 'Admin', role: 'admin', permissions: ['all'],
      created_at: new Date().toISOString()
    }],
    'categories.json': [
      { id:'1', name:'Discord Nitro', slug:'discord-nitro', icon:'💎', color:'#5865F2' },
      { id:'2', name:'Discord Server Boost', slug:'discord-boost', icon:'🚀', color:'#FF73FA' },
      { id:'3', name:'Minecraft Premium', slug:'minecraft-premium', icon:'⛏️', color:'#5C8B1B' },
      { id:'4', name:'Netflix', slug:'netflix', icon:'🎬', color:'#E50914' },
      { id:'5', name:'Crunchyroll', slug:'crunchyroll', icon:'🍥', color:'#F47521' },
      { id:'6', name:'Roblox', slug:'roblox', icon:'🎮', color:'#FF0000' },
      { id:'7', name:'Free Fire Diamonds', slug:'free-fire', icon:'💠', color:'#FF6B35' }
    ],
    'products.json': [
      { id:'1', title:'Nitro Basic', category_id:'1', description:'Discord Nitro Basic - 1 Month. Enjoy custom emoji, animated avatars, and more.', price_pkr:1500, price_inr:450, stock:'in_stock', image:'', featured:true, created_at:new Date().toISOString() },
      { id:'2', title:'Nitro Monthly', category_id:'1', description:'Discord Nitro Full - 1 Month. Unlock all Nitro perks including 2 boosts.', price_pkr:3200, price_inr:950, stock:'in_stock', image:'', featured:true, created_at:new Date().toISOString() },
      { id:'3', title:'Nitro Yearly', category_id:'1', description:'Discord Nitro Full - 1 Year. Best value with all premium features.', price_pkr:28000, price_inr:8500, stock:'in_stock', image:'', featured:false, created_at:new Date().toISOString() },
      { id:'4', title:'Server Boost x1', category_id:'2', description:'1 Server Boost to level up your Discord server.', price_pkr:1800, price_inr:550, stock:'in_stock', image:'', featured:false, created_at:new Date().toISOString() },
      { id:'5', title:'Minecraft Account #1', category_id:'3', description:'Premium Minecraft Java Edition Account. Full access guaranteed.', price_pkr:2500, price_inr:750, stock:'in_stock', image:'', featured:true, created_at:new Date().toISOString() },
      { id:'6', title:'Minecraft Account #2', category_id:'3', description:'Premium Minecraft Java Edition Account. Hypixel ready.', price_pkr:2500, price_inr:750, stock:'in_stock', image:'', featured:false, created_at:new Date().toISOString() },
      { id:'7', title:'Netflix 1 Month', category_id:'4', description:'Netflix Premium 1 Month Subscription. 4K streaming on 4 screens.', price_pkr:1200, price_inr:350, stock:'in_stock', image:'', featured:false, created_at:new Date().toISOString() },
      { id:'8', title:'Crunchyroll Premium', category_id:'5', description:'Crunchyroll Premium - 1 Month. Ad-free anime streaming.', price_pkr:900, price_inr:270, stock:'in_stock', image:'', featured:false, created_at:new Date().toISOString() },
      { id:'9', title:'800 Robux', category_id:'6', description:'800 Robux added to your Roblox account.', price_pkr:1500, price_inr:450, stock:'in_stock', image:'', featured:false, created_at:new Date().toISOString() },
      { id:'10', title:'1000 Diamonds', category_id:'7', description:'1000 Free Fire Diamonds. Instant delivery.', price_pkr:2000, price_inr:600, stock:'in_stock', image:'', featured:true, created_at:new Date().toISOString() }
    ],
    'offers.json': [],
    'reviews.json': [
      { id:'1', discord_username:'StormFan#1234', discord_id:'123456789', content:'Amazing service! Got my Nitro within minutes. Highly recommended!', rating:5, approved:true, created_at:new Date().toISOString() },
      { id:'2', discord_username:'GameKing#5678', discord_id:'987654321', content:'Best shop on Discord. Very trustworthy and fast delivery.', rating:5, approved:true, created_at:new Date().toISOString() }
    ],
    'chats.json': [],
    'social_links.json': [
      { id:'1', platform:'Discord', url:'https://discord.gg/stormforge', icon:'discord', color:'#5865F2' },
      { id:'2', platform:'YouTube', url:'#', icon:'youtube', color:'#FF0000' },
      { id:'3', platform:'TikTok', url:'#', icon:'tiktok', color:'#010101' },
      { id:'4', platform:'Instagram', url:'#', icon:'instagram', color:'#E1306C' },
      { id:'5', platform:'Facebook', url:'#', icon:'facebook', color:'#1877F2' }
    ]
  };

  Object.entries(defaults).forEach(([file, data]) => {
    const fp = path.join(DATA_DIR, file);
    if (!fs.existsSync(fp)) fs.writeFileSync(fp, JSON.stringify(data, null, 2));
  });
}

function read(col) {
  const fp = path.join(DATA_DIR, `${col}.json`);
  if (!fs.existsSync(fp)) return col === 'settings' ? {} : [];
  return JSON.parse(fs.readFileSync(fp, 'utf8'));
}

function write(col, data) {
  fs.writeFileSync(path.join(DATA_DIR, `${col}.json`), JSON.stringify(data, null, 2));
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

module.exports = { initDB, read, write, generateId };
