const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'stormforge-secret-key-2024';

function authMiddleware(req, res, next) {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

function requirePermission(perm) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
    const perms = req.user.permissions || [];
    if (perms.includes('all') || perms.includes(perm)) return next();
    res.status(403).json({ error: 'Insufficient permissions' });
  };
}

module.exports = { authMiddleware, requirePermission, SECRET };
