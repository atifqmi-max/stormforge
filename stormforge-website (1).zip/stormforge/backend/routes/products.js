const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { read, write, generateId } = require('../../database/db');
const { authMiddleware, requirePermission } = require('../middleware/auth');

const uploadDir = path.join(__dirname, '../../frontend/assets/uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// Public: get all products
router.get('/', (req, res) => {
  const products = read('products');
  const categories = read('categories');
  const { category_id, featured, limit } = req.query;
  let result = products;
  if (category_id) result = result.filter(p => p.category_id === category_id);
  if (featured === 'true') result = result.filter(p => p.featured);
  if (limit) result = result.slice(0, parseInt(limit));
  // Attach category info
  result = result.map(p => ({
    ...p,
    category: categories.find(c => c.id === p.category_id) || null
  }));
  res.json(result);
});

// Public: get single product
router.get('/:id', (req, res) => {
  const products = read('products');
  const product = products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Not found' });
  res.json(product);
});

// Admin: create product
router.post('/', authMiddleware, requirePermission('products'), upload.single('image'), (req, res) => {
  const { title, category_id, description, price_pkr, price_inr, stock, featured } = req.body;
  const products = read('products');
  const newProduct = {
    id: generateId(), title, category_id, description,
    price_pkr: parseFloat(price_pkr), price_inr: parseFloat(price_inr),
    stock: stock || 'in_stock',
    image: req.file ? `/assets/uploads/${req.file.filename}` : '',
    featured: featured === 'true' || featured === true,
    created_at: new Date().toISOString()
  };
  products.push(newProduct);
  write('products', products);
  res.json({ success: true, product: newProduct });
});

// Admin: update product
router.put('/:id', authMiddleware, requirePermission('products'), upload.single('image'), (req, res) => {
  const products = read('products');
  const idx = products.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const { title, category_id, description, price_pkr, price_inr, stock, featured } = req.body;
  products[idx] = {
    ...products[idx], title, category_id, description,
    price_pkr: parseFloat(price_pkr), price_inr: parseFloat(price_inr),
    stock, featured: featured === 'true' || featured === true,
    image: req.file ? `/assets/uploads/${req.file.filename}` : products[idx].image,
    updated_at: new Date().toISOString()
  };
  write('products', products);
  res.json({ success: true, product: products[idx] });
});

// Admin: delete product
router.delete('/:id', authMiddleware, requirePermission('products'), (req, res) => {
  let products = read('products');
  products = products.filter(p => p.id !== req.params.id);
  write('products', products);
  res.json({ success: true });
});

module.exports = router;
