const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { read, write, generateId } = require('../../database/db');
const { authMiddleware, requirePermission } = require('../middleware/auth');

const uploadDir = path.join(__dirname, '../../frontend/assets/uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({ destination: uploadDir, filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname) });
const upload = multer({ storage });

// Public: get active offers
router.get('/', (req, res) => {
  const offers = read('offers');
  const now = new Date();
  const active = offers.filter(o => !o.expiry_date || new Date(o.expiry_date) > now);
  res.json(active);
});

// Admin: get all offers
router.get('/admin/all', authMiddleware, requirePermission('offers'), (req, res) => {
  res.json(read('offers'));
});

// Admin: create offer
router.post('/', authMiddleware, requirePermission('offers'), upload.single('image'), (req, res) => {
  const { title, description, price_pkr, price_inr, expiry_date } = req.body;
  const offers = read('offers');
  const newOffer = {
    id: generateId(), title, description,
    price_pkr: parseFloat(price_pkr), price_inr: parseFloat(price_inr),
    expiry_date: expiry_date || null,
    image: req.file ? `/assets/uploads/${req.file.filename}` : '',
    created_at: new Date().toISOString()
  };
  offers.push(newOffer);
  write('offers', offers);
  res.json({ success: true, offer: newOffer });
});

// Admin: update offer
router.put('/:id', authMiddleware, requirePermission('offers'), upload.single('image'), (req, res) => {
  const offers = read('offers');
  const idx = offers.findIndex(o => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const { title, description, price_pkr, price_inr, expiry_date } = req.body;
  offers[idx] = { ...offers[idx], title, description,
    price_pkr: parseFloat(price_pkr), price_inr: parseFloat(price_inr),
    expiry_date: expiry_date || null,
    image: req.file ? `/assets/uploads/${req.file.filename}` : offers[idx].image
  };
  write('offers', offers);
  res.json({ success: true });
});

// Admin: delete offer
router.delete('/:id', authMiddleware, requirePermission('offers'), (req, res) => {
  let offers = read('offers');
  offers = offers.filter(o => o.id !== req.params.id);
  write('offers', offers);
  res.json({ success: true });
});

module.exports = router;
