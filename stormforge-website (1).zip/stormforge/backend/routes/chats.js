const express = require('express');
const router = express.Router();
const { read, write, generateId } = require('../../database/db');
const { authMiddleware, requirePermission } = require('../middleware/auth');

// Public: start chat session
router.post('/start', (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name and email required' });
  const chats = read('chats');
  const newChat = {
    id: generateId(), name, email, status: 'open',
    messages: [{ from: 'system', text: `Welcome ${name}! How can we help you today?`, time: new Date().toISOString() }],
    created_at: new Date().toISOString()
  };
  chats.push(newChat);
  write('chats', chats);
  res.json({ success: true, chatId: newChat.id, chat: newChat });
});

// Public: get chat by id
router.get('/:id', (req, res) => {
  const chats = read('chats');
  const chat = chats.find(c => c.id === req.params.id);
  if (!chat) return res.status(404).json({ error: 'Chat not found' });
  res.json(chat);
});

// Public: send message
router.post('/:id/message', (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'Message required' });
  const chats = read('chats');
  const idx = chats.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Chat not found' });
  if (chats[idx].status === 'closed') return res.status(400).json({ error: 'Chat is closed' });
  chats[idx].messages.push({ from: 'user', text: message, time: new Date().toISOString() });
  write('chats', chats);
  res.json({ success: true, chat: chats[idx] });
});

// Admin: get all chats
router.get('/', authMiddleware, requirePermission('chat'), (req, res) => {
  res.json(read('chats'));
});

// Admin: reply to chat
router.post('/:id/reply', authMiddleware, requirePermission('chat'), (req, res) => {
  const { message } = req.body;
  const chats = read('chats');
  const idx = chats.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  chats[idx].messages.push({ from: 'admin', text: message, time: new Date().toISOString(), admin_name: req.user.name });
  write('chats', chats);
  // Email notification would go here
  res.json({ success: true, chat: chats[idx] });
});

// Admin: close chat
router.put('/:id/close', authMiddleware, requirePermission('chat'), (req, res) => {
  const chats = read('chats');
  const idx = chats.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  chats[idx].status = 'closed';
  write('chats', chats);
  res.json({ success: true });
});

// Admin: delete chat
router.delete('/:id', authMiddleware, requirePermission('chat'), (req, res) => {
  let chats = read('chats');
  chats = chats.filter(c => c.id !== req.params.id);
  write('chats', chats);
  res.json({ success: true });
});

module.exports = router;
