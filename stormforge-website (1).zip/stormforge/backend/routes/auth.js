const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { read, write, generateId } = require('../../database/db');
const { authMiddleware, SECRET } = require('../middleware/auth');

// Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = read('users');
  const user = users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign(
    { id: user.id, email: user.email, name: user.name, role: user.role, permissions: user.permissions },
    SECRET, { expiresIn: '7d' }
  );
  res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
  res.json({ success: true, token, user: { id: user.id, email: user.email, name: user.name, role: user.role, permissions: user.permissions } });
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true });
});

// Get current user
router.get('/me', authMiddleware, (req, res) => {
  res.json({ user: req.user });
});

// Update credentials (admin only)
router.put('/update-credentials', authMiddleware, (req, res) => {
  const { userId, email, password, name } = req.body;
  if (req.user.role !== 'admin' && req.user.id !== userId)
    return res.status(403).json({ error: 'Forbidden' });
  const users = read('users');
  const idx = users.findIndex(u => u.id === (userId || req.user.id));
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  if (email) users[idx].email = email;
  if (name) users[idx].name = name;
  if (password) users[idx].password = bcrypt.hashSync(password, 10);
  write('users', users);
  res.json({ success: true });
});

// Create staff (admin only)
router.post('/staff', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const { email, password, name, permissions } = req.body;
  const users = read('users');
  if (users.find(u => u.email === email))
    return res.status(400).json({ error: 'Email already exists' });
  const newUser = {
    id: generateId(), email, name, role: 'staff',
    password: bcrypt.hashSync(password, 10),
    permissions: permissions || ['chat'],
    created_at: new Date().toISOString()
  };
  users.push(newUser);
  write('users', users);
  res.json({ success: true, user: { ...newUser, password: undefined } });
});

// List staff (admin only)
router.get('/staff', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const users = read('users').filter(u => u.role === 'staff');
  res.json(users.map(u => ({ ...u, password: undefined })));
});

// Delete staff
router.delete('/staff/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  let users = read('users');
  users = users.filter(u => u.id !== req.params.id);
  write('users', users);
  res.json({ success: true });
});

module.exports = router;
