const express = require('express');
const router = express.Router();
const { read, write, generateId } = require('../../database/db');
const { authMiddleware, requirePermission } = require('../middleware/auth');

// Public: get approved reviews
router.get('/', (req, res) => {
  const reviews = read('reviews').filter(r => r.approved);
  res.json(reviews);
});

// Public: submit review
router.post('/', (req, res) => {
  const { discord_username, discord_id, content, rating } = req.body;
  if (!discord_username || !content || !rating)
    return res.status(400).json({ error: 'Missing required fields' });
  const reviews = read('reviews');
  const newReview = {
    id: generateId(), discord_username, discord_id, content,
    rating: parseInt(rating), approved: false,
    created_at: new Date().toISOString()
  };
  reviews.push(newReview);
  write('reviews', reviews);
  res.json({ success: true, message: 'Review submitted for approval' });
});

// Admin: get all reviews
router.get('/admin/all', authMiddleware, requirePermission('reviews'), (req, res) => {
  res.json(read('reviews'));
});

// Admin: approve review
router.put('/:id/approve', authMiddleware, requirePermission('reviews'), (req, res) => {
  const reviews = read('reviews');
  const idx = reviews.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  reviews[idx].approved = true;
  write('reviews', reviews);
  res.json({ success: true });
});

// Admin: edit review
router.put('/:id', authMiddleware, requirePermission('reviews'), (req, res) => {
  const reviews = read('reviews');
  const idx = reviews.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const { content, rating } = req.body;
  if (content) reviews[idx].content = content;
  if (rating) reviews[idx].rating = parseInt(rating);
  write('reviews', reviews);
  res.json({ success: true });
});

// Admin: delete review
router.delete('/:id', authMiddleware, requirePermission('reviews'), (req, res) => {
  let reviews = read('reviews');
  reviews = reviews.filter(r => r.id !== req.params.id);
  write('reviews', reviews);
  res.json({ success: true });
});

module.exports = router;
