const express = require('express');
const router = express.Router();
const { read, write, generateId } = require('../../database/db');
const { authMiddleware } = require('../middleware/auth');

// Public: get settings (safe subset)
router.get('/', (req, res) => {
  const s = read('settings');
  res.json({ shop_name: s.shop_name, shop_tagline: s.shop_tagline, discord_invite: s.discord_invite });
});

// Admin: update settings
router.put('/', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const current = read('settings');
  const updated = { ...current, ...req.body };
  write('settings', updated);
  res.json({ success: true, settings: updated });
});

// Public: get social links
router.get('/social', (req, res) => {
  res.json(read('social_links'));
});

// Admin: add social link
router.post('/social', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const { platform, url, icon, color } = req.body;
  const links = read('social_links');
  const newLink = { id: generateId(), platform, url, icon, color };
  links.push(newLink);
  write('social_links', links);
  res.json({ success: true, link: newLink });
});

// Admin: update social link
router.put('/social/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const links = read('social_links');
  const idx = links.findIndex(l => l.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  links[idx] = { ...links[idx], ...req.body };
  write('social_links', links);
  res.json({ success: true });
});

// Admin: delete social link
router.delete('/social/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  let links = read('social_links');
  links = links.filter(l => l.id !== req.params.id);
  write('social_links', links);
  res.json({ success: true });
});

module.exports = router;
