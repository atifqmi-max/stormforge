const express = require('express');
const router = express.Router();
const { read, write, generateId } = require('../../database/db');
const { authMiddleware, requirePermission } = require('../middleware/auth');

// Public: get all categories
router.get('/', (req, res) => {
  const categories = read('categories');
  const products = read('products');
  const result = categories.map(cat => ({
    ...cat,
    product_count: products.filter(p => p.category_id === cat.id).length
  }));
  res.json(result);
});

// Public: get category by slug
router.get('/:slug', (req, res) => {
  const categories = read('categories');
  const cat = categories.find(c => c.slug === req.params.slug);
  if (!cat) return res.status(404).json({ error: 'Not found' });
  const products = read('products').filter(p => p.category_id === cat.id);
  res.json({ ...cat, products });
});

// Admin: create category
router.post('/', authMiddleware, requirePermission('products'), (req, res) => {
  const { name, icon, color } = req.body;
  const categories = read('categories');
  const slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  if (categories.find(c => c.slug === slug))
    return res.status(400).json({ error: 'Category already exists' });
  const newCat = { id: generateId(), name, slug, icon: icon || '📦', color: color || '#00c8ff', created_at: new Date().toISOString() };
  categories.push(newCat);
  write('categories', categories);
  res.json({ success: true, category: newCat });
});

// Admin: update category
router.put('/:id', authMiddleware, requirePermission('products'), (req, res) => {
  const categories = read('categories');
  const idx = categories.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const { name, icon, color } = req.body;
  categories[idx] = { ...categories[idx], name, icon, color };
  write('categories', categories);
  res.json({ success: true, category: categories[idx] });
});

// Admin: delete category
router.delete('/:id', authMiddleware, requirePermission('products'), (req, res) => {
  let categories = read('categories');
  categories = categories.filter(c => c.id !== req.params.id);
  write('categories', categories);
  // Also delete products in this category
  let products = read('products');
  products = products.filter(p => p.category_id !== req.params.id);
  write('products', products);
  res.json({ success: true });
});

module.exports = router;
